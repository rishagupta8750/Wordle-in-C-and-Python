import csv
import os
import random
import sys
import time
def display(trials,extra,z):
    pos = z+1
    os.system('cls' if os.name == 'nt' else 'clear')
    for i in range(len(trials)):
        for j in trials[i]:
            print(" ",j," ",end="")
        print()
    print("Words in the sentence are: ",extra)
    print("Rounds occured = ",pos)
with open("wordle.csv","r") as myFile:
    reade = csv.reader(myFile)
    dictionary = []
    for i in reade:
        dictionary.append(i[0])
leng = int(input("How Many Trials Do You want?: "))
#This section will read and and store everything in dictionary
#os.system('cls' if os.name == 'nt' else 'clear')
#We will pick a random integral value
os.system('cls' if os.name == 'nt' else 'clear')
rword = random.randint(0,len(dictionary)-1)
rword = dictionary[rword]
#Now rword contains the letter.
#We will convert rword into a list for ease
wordle = []
for i in rword:
    wordle.append(i)
trials = []
for i in range(leng):
    trials.append(["_","_","_","_","_"])
guess=""
extrawords=[]
os.system('cls' if os.name == 'nt' else 'clear')
print("Welcome to Wordle!")

z=-1
with open("wordlepp.csv","r") as myFile:
    reade = csv.reader(myFile)
    dictionary = []
    for i in reade:
        dictionary.append(i[0])
display(trials,extrawords,z)
for z in range(0,leng):
    #The user gets 6 tries, like in the original wordle game
    guess=""
    while(guess not in dictionary):
        guess = input("Your guess? ")
        if guess not in dictionary:
            print("Not a valid word, try again ")
            time.sleep(2)
            display(trials,extrawords,z)
    
    guess.lower()
    for i in range(len(guess)):
        if guess[i]==wordle[i] and len(guess)==5:
            trials[z][i]=guess[i]
        elif(guess[i] in wordle and guess[i] not in extrawords):
            extrawords.append(guess[i])
    display(trials,extrawords,z)
    if(guess == rword):
        print("Conratulations, you won!")
        sys.exit()
print("Better Luck Next Time, the word was -",rword,"-")
    #If the word is in correct position, we print the word there.
    #If the word is not in correct position, but exists in the word, we print it on a different side