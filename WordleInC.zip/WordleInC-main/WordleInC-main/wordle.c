#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <time.h>

// All user-defined functions here
void stop(int milliseconds);
void cls();
void loading();
void start();
void choose();
void help();
void exitGame();
void nextslide(int a);
void generateLevel(int level);
void begin4();
void rand4();
int findlen4();
void generateGuess4();
void generateSol4();
void displayWordle4();
void printSol(int d);
int checkExist4(char* buffer);
int checkSize4(char* buffer);
void input4();
void editSol4();
void winCheck4();
void begin5();
void rand5();
int findlen5();
void generateGuess5();
void generateSol5();
void displayWordle5();
int checkExist5(char* buffer);
int checkSize5(char* buffer);
void input5();
void editSol5();
void winCheck5();
void begin6();
void rand6();
int findlen6();
void generateGuess6();
void generateSol6();
void displayWordle6();
int checkExist6(char* buffer);
int checkSize6(char* buffer);
void input6();
void editSol6();
void winCheck6();
void scramble();
void mixup4();
void mixup5();
void mixup6();
void scramble5();
void scramble6();
void scramble4();
int randint(int min_num, int max_num);

// All global variables
char* word;        // Word to be guessed
char* guessWord;   // User guess
int* sol;          // Array containing all the solutions
int* guess;        // Array containing the user inputs
int round = 0;     // Indicates the current round

// Main function
int main()
{
    printf("Welcome to the Wordle Game\n");
    printf("Press 1 to begin\n");
    printf("Press 2 to play a game of scramble!\n");
    printf("Press 3 to exit\n");
    int choice;
    printf("Enter your choice here: ");
    scanf("%d", &choice);
    switch (choice)
    {
        case 1:
            start();
            break;
        case 2:
            printf("You have chosen to play scramble\n");
            printf("Press enter to continue\n");
            int ch;
            scanf("%d", &ch);
            cls();
            scramble();
            break;
        case 3:
            exitGame();
            break;
        default:
            printf("Invalid choice\n");
            main();
    }
    start();
    return 0;
}

void cls()
{
    system("clear"); // Use "cls" for Windows
}

void stop(int milliseconds)
{
    usleep(milliseconds * 1000);
}

void loading()
{
    printf("loading...\n");
    printf("Press enter to continue");
    int ch;
    scanf("%d", &ch);
    cls();
}

void exitGame()
{
    cls();
    printf("Thank you for playing\n");
    printf("Exiting\n");
    printf("Press any key to continue\n");
    int ch;
    scanf("%d", &ch);
    cls();
    exit(0);
}

void help()
{
    cls();
    printf("This is a guided tutorial");
    nextslide(3);
    printf("Welcome to Wordle, a Word Guessing game.\n");
    printf("The original version was released in October, 2021 by Josh Wardle.\n");
    printf("This is a Remastered Version of the game in C.\n");
    nextslide(7);
    printf("The game begins with a 6 row matrix as given below:\n");
    generateLevel(5);
    nextslide(5);
    printf("Let us learn using an example");
    nextslide(2);
    printf("Let us say you have to guess the GUESS 'PLANT'");
    printf("\nYou won't be told what you are supposed to guess, it is just for the example");
    nextslide(7);
    printf("So you enter your first guess: STAND");
    nextslide(5);
    printf("The computer will return: ");
    printf("S :[ T :/ A :) N :) D :[");
    nextslide(10);
    printf("\nThis was because: \n");
    printf(":) means that the letter is in the right location\n");
    printf(":/ means that the letter exists in the GUESS but is not in the right location\n");
    printf(":[ means that the letter does not exist in the GUESS\n");
    nextslide(10);
    printf("So\nS :[ T :/ A :) N :) D :[ \nMeans that\n");
    printf("S and D are not in the original GUESS, i.e. PLANT\n");
    printf("T is in the wrong location and A and N are in the right location");
    nextslide(15);
    printf("This will fill one row.");
    printf("\nThe game will go on till either you find the correct GUESS or you use up your six attempts\n");
    printf("You will be revealed the answer when the game ends.");
    nextslide(9);
    printf("All the Best");
    printf("\n\n---\nEnter any key to continue\n");
    int ch;
    scanf("%d", &ch);
    cls();
}

void nextslide(int a)
{
    stop(a * 1000);
    cls();
}

void start()
{
    round = 0;
    cls();
    printf("Welcome to The Wordle Game\n");
    printf("---Press 1 to continue\n");
    printf("---Press 2 for help\n");
    printf("---Press 3 to exit\n");
    int choice;
    printf("Enter your choice here: ");
    scanf("%d", &choice);
    switch (choice)
    {
        case 1:
            loading();
            choose();
            break;
        case 2:
            loading();
            help();
            break;
        case 3:
            exitGame();
            break;
        default:
            printf("Invalid choice\n");
            start();
    }
}

void choose()
{
    cls();
    printf("Choose your level\n");
    printf("---Press 1 for 4 letters\n");
    printf("---Press 2 for 5 letters\n");
    printf("---Press 3 for 6 letters\n");
    printf("---Press 4 to go back\n");
    int choice;
    printf("Enter your choice here: ");
    scanf("%d", &choice);
    switch (choice)
    {
        case 1:
            loading();
            printf("You have chosen 4 letters\n");
            begin4();
            break;
        case 2:
            loading();
            printf("You have chosen 5 letters\n");
            begin5();
            break;
        case 3:
            loading();
            printf("You have chosen 6 letters\n");
            begin6();
            break;
        case 4:
            start();
            break;
        default:
            printf("Invalid choice\n");
            choose();
            break;
    }
}

void generateLevel(int level)
{
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < level; j++)
            printf(" _ ");
        printf("\n");
    }
}

// 4-letter word game functions

void begin4()
{
    cls();
    printf("Welcome to the 4 letter game\n");
    printf("You have 6 attempts to guess the word\n");
    printf("The word is a 4 letter word\n");
    printf("Press enter to continue\n");
    int ch;
    scanf("%d", &ch);
    cls();
    rand4();
    generateGuess4();
    generateSol4();
    displayWordle4();
    for (int i = 0; i < 6; i++)
    {
        input4();
        editSol4();
        cls();
        displayWordle4();
        winCheck4();
        round++;
    }
    if (round == 6)
    {
        cls();
        printf("You Lost!\n");
        printf("The word was %s\n", word);
        printf("Press enter to continue\n");
        int a;
        scanf("%d", &a);
        start();
    }
}

void rand4()
{
    FILE *f;
    f = fopen("common4.txt", "r");
    if (!f)
    {
        printf("Error: common4.txt file not found\n");
        exit(1);
    }
    word = (char*)malloc(5 * sizeof(char));
    int size = findlen4();
    int random = randint(1, size);
    for (int i = 0; i < random; i++)
    {
        fscanf(f, "%s", word);
    }
    fclose(f);
}

int findlen4()
{
    FILE *f;
    f = fopen("common4.txt", "r");
    if (!f)
    {
        printf("Error: common4.txt file not found\n");
        exit(1);
    }
    int count = 0;
    char c[5];
    while (fscanf(f, "%s", c) != EOF)
        count++;
    fclose(f);
    return count;
}

void generateGuess4()
{
    guessWord = (char*)malloc(5 * sizeof(char));
}

void generateSol4()
{
    sol = (int*)malloc(24 * sizeof(int));
    for (int i = 0; i < 24; i++)
        sol[i] = 0;
}

void displayWordle4()
{
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            switch (sol[i * 4 + j])
            {
                case 1:
                    printf(":) ");
                    break;
                case 2:
                    printf(":/ ");
                    break;
                default:
                    printf(":[ ");
            }
        }
        printf("\n");
    }
}

void printSol(int d)
{
    printf("\nThe Sol array is: ");
    for (int i = 0; i < d * 6; i++)
        printf("%d ", sol[i]);
}

int checkExist4(char* buffer)
{
    FILE *f;
    f = fopen("common4.txt", "r");
    if (!f)
    {
        printf("Error: common4.txt file not found\n");
        exit(1);
    }
    char *temp;
    temp = (char*)malloc(5 * sizeof(char));
    while (fscanf(f, "%s", temp) != EOF)
    {
        if (strcmp(temp, buffer) == 0)
        {
            free(temp);
            return 1;
        }
    }
    free(temp);
    fclose(f);
    return 0;
}

int checkSize4(char* buffer)
{
    if (strlen(buffer) == 4)
        return 1;
    return 0;
}

void input4()
{
    printf("Enter your guess: ");
    scanf("%s", guessWord);
    while (!checkExist4(guessWord) || !checkSize4(guessWord))
    {
        printf("Invalid word\n");
        printf("Enter your guess: ");
        scanf("%s", guessWord);
    }
    guess = (int*)malloc(4 * sizeof(int));
    for (int i = 0; i < 4; i++)
        guess[i] = (int)guessWord[i];
}

void editSol4()
{
    for (int i = 0; i < 4; i++)
    {
        if (guessWord[i] == word[i])
            sol[round * 4 + i] = 1;
        else
        {
            int found = 0;
            for (int j = 0; j < 4; j++)
            {
                if (guessWord[i] == word[j])
                {
                    found = 1;
                    break;
                }
            }
            if (found)
                sol[round * 4 + i] = 2;
            else
                sol[round * 4 + i] = 0;
        }
    }
}

void winCheck4()
{
    int count = 0;
    for (int i = 0; i < 4; i++)
    {
        if (sol[round * 4 + i] == 1)
            count++;
    }
    if (count == 4)
    {
        printf("You Won!\n");
        printf("The word was %s\n", word);
        printf("Press enter to continue\n");
        int a;
        scanf("%d", &a);
        start();
    }
}

// Similar functions for 5-letter and 6-letter games
// omitted for brevity...

// Scramble game functions

void scramble()
{
    printf("Choose your level\n");
    printf("---Press 1 for 4 letters\n");
    printf("---Press 2 for 5 letters\n");
    printf("---Press 3 for 6 letters\n");
    printf("---Press 4 to go back\n");
    int choice;
    printf("Enter your choice here: ");
    scanf("%d", &choice);
    switch (choice)
    {
        case 1:
            loading();
            scramble4();
            break;
        case 2:
            loading();
            scramble5();
            break;
        case 3:
            loading();
            scramble6();
            break;
        case 4:
            start();
            break;
        default:
            printf("Invalid choice\n");
            scramble();
            break;
    }
}

void scramble4()
{
    printf("You have chosen 4 letters\n");
    FILE *f;
    f = fopen("common4.txt", "r");
    if (!f)
    {
        printf("Error: common4.txt file not found\n");
        exit(1);
    }
    int size = findlen4();
    int random = randint(1, size);
    char* buffer;
    buffer = (char*)malloc(5 * sizeof(char));
    for (int i = 0; i < random; i++)
    {
        fscanf(f, "%s", buffer);
    }
    fclose(f);
    printf("The original word was: %s\n", buffer);
    int flag = 0;
    while (!flag)
    {
        printf("Shuffled Word: ");
        mixup4(buffer);
        printf("\n");
        printf("Can you guess the original word?\n");
        char guess[5];
        scanf("%s", guess);
        if (strcmp(buffer, guess) == 0)
        {
            printf("You guessed it right!\n");
            flag = 1;
        }
        else
            printf("Wrong guess, try again\n");
    }
    free(buffer);
    printf("Press enter to continue\n");
    int a;
    scanf("%d", &a);
    start();
}

void mixup4(char* word)
{
    int len = strlen(word);
    for (int i = 0; i < len; i++)
    {
        int j = randint(0, len - 1);
        char temp = word[i];
        word[i] = word[j];
        word[j] = temp;
    }
    printf("%s", word);
}

// Similar functions for 5-letter and 6-letter scramble games
// omitted for brevity...

int randint(int min_num, int max_num)
{
    int result = 0, low_num = 0, hi_num = 0;

    if (min_num < max_num)
    {
        low_num = min_num;
        hi_num = max_num + 1;
    }
    else
    {
        low_num = max_num;
        hi_num = min_num + 1;
    }

    srand(time(NULL));
    result = (rand() % (hi_num - low_num)) + low_num;
    return result;
}
